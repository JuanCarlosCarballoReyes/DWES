<?php $__env->startSection('title', 'Argo Create Serie'); ?> 

<?php $__env->startSection('content'); ?>

<div class="table-responsive small">
    <table class="table table-striped table-sm">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Year</th> 
                <th scope="col">Seasons</th>
                <th scope="col">Duracion</th>
                <th scope="col">Protagonista</th>
                <th scope="col">Genero</th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
           
            <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($serie->id); ?></td>
                    <td><?php echo e($serie->title); ?></td>
                    <td><?php echo e($serie->year); ?></td>
                    <td><?php echo e($serie->seasons); ?></td>
                    <td><?php echo e($serie->duracion); ?></td>
                    <td><?php echo e($serie->protagonista); ?></td>
                    <td><?php echo e($serie->genero); ?></td>
                    <td>
                        <a href="<?php echo e(url('serie/' . $serie->id)); ?>" class="btn btn-primary">View</a>
                        <a href="<?php echo e(url('serie/' . $serie->id . '/edit')); ?>" class="btn btn-primary">Edit</a> 
        <form class="formDelete" action="<?php echo e(url('serie/' . $serie->id)); ?>" method="post" style="display: inline-block">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn-danger btn" type="submit" >Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <a class="btn-primary btn" href="<?php echo e(url('serie/create')); ?>" >Link to create</a>
    <form id = "formDelete" action = "<?php echo e(url ('')); ?>" method = "post" style = "display: inline-block"> 
    <?php echo csrf_field(); ?>
    <?php echo method_field('delete'); ?>
    </form>
</div>

<script>
    const forms = document.querySelectorAll(".formDelete");
    forms.forEach(function(form){
        form.onsubmit = () => {
            return confirm("Seguro?");
        }
    });
    
    const ahrefs = document.querySelectorAll(".hrefDelete");
    ahrefs.forEach(function(ahref){
        ahref.onclick = (event) => {
            let url = event.target.dataset.url;
            if (confirm('Seguro?')) {
                let formDelete = document.getElementById("formDelete");
                formDelete.action = url;
                event.preventDefault();
                formDelete.submit();
            }
        }
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/tarea13nov/resources/views/serie/index.blade.php ENDPATH**/ ?>