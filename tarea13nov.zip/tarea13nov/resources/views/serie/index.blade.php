@extends('app.base')

@section('title', 'Argo Create Serie') 

@section('content')

<div class="table-responsive small">
    <table class="table table-striped table-sm">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Year</th> 
                <th scope="col">Seasons</th>
                <th scope="col">Duracion</th>
                <th scope="col">Protagonista</th>
                <th scope="col">Genero</th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
           
            @foreach($series as $serie)
                <tr>
                    <td>{{ $serie->id }}</td>
                    <td>{{ $serie->title }}</td>
                    <td>{{ $serie->year }}</td>
                    <td>{{ $serie->seasons }}</td>
                    <td>{{ $serie->duracion }}</td>
                    <td>{{ $serie->protagonista }}</td>
                    <td>{{ $serie->genero }}</td>
                    <td>
                        <a href="{{ url('serie/' . $serie->id) }}" class="btn btn-primary">View</a>
                        <a href="{{ url('serie/' . $serie->id . '/edit')}}" class="btn btn-primary">Edit</a> 
        <form class="formDelete" action="{{ url('serie/' . $serie->id) }}" method="post" style="display: inline-block">
                        @csrf
                        @method('delete')
                        <button class="btn-danger btn" type="submit" >Delete</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <a class="btn-primary btn" href="{{ url('serie/create') }}" >Link to create</a>
    <form id = "formDelete" action = "{{ url ('') }}" method = "post" style = "display: inline-block"> 
    @csrf
    @method('delete')
    </form>
</div>

<script>
    const forms = document.querySelectorAll(".formDelete");
    forms.forEach(function(form){
        form.onsubmit = () => {
            return confirm("Seguro?");
        }
    });
    
    const ahrefs = document.querySelectorAll(".hrefDelete");
    ahrefs.forEach(function(ahref){
        ahref.onclick = (event) => {
            let url = event.target.dataset.url;
            if (confirm('Seguro?')) {
                let formDelete = document.getElementById("formDelete");
                formDelete.action = url;
                event.preventDefault();
                formDelete.submit();
            }
        }
    });
</script>

@endsection